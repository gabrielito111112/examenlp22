package com.examenFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EfLp2YordyApazaApplicationTests {

	@Test
	void contextLoads() {
	}

}
