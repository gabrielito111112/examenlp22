package com.examenFinal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examenFinal.entidades.Atencion;

public interface AtencionRepository extends JpaRepository<Atencion, Long> {}

