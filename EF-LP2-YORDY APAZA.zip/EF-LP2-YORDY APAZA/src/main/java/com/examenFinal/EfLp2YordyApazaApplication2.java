package com.examenFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EfLp2YordyApazaApplication2 {

	public static void main(String[] args) {
		SpringApplication.run(EfLp2YordyApazaApplication2.class, args);
	}

}
